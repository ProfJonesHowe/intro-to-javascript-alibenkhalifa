function greetUser() {
  let name = document.getElementById("nameInput").value;
  let message = "Hello, " + name + "! Welcome to JavaScript.";
  document.getElementById("greeting").innerHTML = message;
}
