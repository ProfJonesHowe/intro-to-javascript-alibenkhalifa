// Output in different ways
document.getElementById("demo").innerHTML = "This is written in JavaScript!";
alert("This is an alert box!");
console.log("This is logged in the console.");
