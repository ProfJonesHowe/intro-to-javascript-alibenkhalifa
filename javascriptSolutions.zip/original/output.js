function showInnerHTML() {
  document.getElementById("output1").innerHTML = "Hello from innerHTML!";
}

function useDocumentWrite() {
  document.write("This replaces the page content! Not recommended.");
}

function showAlert() {
  alert("This is an alert box!");
}

function showConsole() {
  console.log("This message is in the console.");
}
