// Output in different ways using a button
function showOutputs() {
  const message = "This text was set using innerHTML from script.js.";
  document.getElementById("demo").innerHTML = message;

  alert("Button clicked! This alert is coming from showOutputs().");

  console.log("showOutputs() ran and updated the page.");
  console.log("Current message is: " + message);
}
