function showInnerHTML() {
  document.getElementById("output1").innerHTML =
    "Updated with innerHTML from output.js!";
}

function useDocumentWrite() {
  document.write("<h3>document.write() replaced all of the original page content.</h3>");
}

function showAlert() {
  alert("Alert from showAlert(): JavaScript output practice is working!");
}

function showConsole() {
  console.log("showConsole() was called. You are now seeing console.log output.");
}

// New function for practice and the final challenge
function showCustomMessage() {
  let topic = "JavaScript output methods";
  let reminder = "Check both the web page and the console.";

  const text = "Custom message about " + topic +
               ". " + reminder;

  document.getElementById("output2").innerHTML = text;
  console.log("Custom function message:", text);
}
