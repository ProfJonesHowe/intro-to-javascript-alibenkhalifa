// Functions and user input practice
function greetUser() {
  let name = document.getElementById("nameInput").value;
  let feeling = document.getElementById("feelingInput").value;

  let message = "Hi, " + name + "! You said you are feeling "" +
                feeling + "" today. Thanks for trying this JavaScript demo.";
  document.getElementById("greeting").innerHTML = message;
}

// Clear button: reset inputs and message
function clearForm() {
  document.getElementById("nameInput").value = "";
  document.getElementById("feelingInput").value = "";
  document.getElementById("greeting").innerHTML = "";
}

// Final Challenge: new variables, function, text on page and console
let className = "Intro to JavaScript";
let meetingTime = "Monday 6:30pm-8:50pm";

function runFinalChallenge() {
  let message = "Class: " + className + " meets on " + meetingTime + ".";

  // Output on the page
  document.getElementById("challengeOutput").innerHTML = message;

  // Output in the console
  console.log("Final challenge message:", message);
}
