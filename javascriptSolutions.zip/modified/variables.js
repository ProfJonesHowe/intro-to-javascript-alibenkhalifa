// Using let with updated values
let name = "Ali";
let age = 22;
let isStudent = true;

// Display basic info
document.getElementById("demo1").innerHTML =
  "Name: " + name + "<br>Age: " + age + "<br>Student: " + isStudent;

// More variables about location
var city = "Latham";          // Function-scoped
let state = "NY";             // Block-scoped
const country = "USA";        // Cannot be reassigned

document.getElementById("demo2").innerHTML =
  "Location: " + city + ", " + state + ", " + country;

// New practice variables
let favoriteLanguage = "JavaScript"; // new string variable
let creditsCompleted = 90;           // new number variable

document.getElementById("demo3").innerHTML =
  "Favorite language: " + favoriteLanguage +
  "<br>Credits completed: " + creditsCompleted;
